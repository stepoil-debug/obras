@echo off
start "" "https://stepsolution-obras.netlify.app/api/obras?health=1"
