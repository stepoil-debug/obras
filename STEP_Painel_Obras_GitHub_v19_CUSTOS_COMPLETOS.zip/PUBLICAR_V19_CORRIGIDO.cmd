@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul

title STEP Obras Base - Publicar v19 Custos Completos

echo ======================================================
echo   STEP OBRAS BASE - PUBLICADOR V19 CUSTOS COMPLETOS
echo   GitHub + painel online
echo ======================================================
echo.

set "PROJETO=C:\Users\douglas.tabella\Downloads\Obras Base Step\step_painel_obras_netlify_v5"
set "REPO=https://github.com/stepsolutions-obras/stepsolutions-obrasbase.git"
set "BRANCH=main"
set "SRC=%~dp0"

if not exist "%PROJETO%" (
  echo [ERRO] Pasta do projeto não encontrada:
  echo %PROJETO%
  pause
  exit /b 1
)

where git >nul 2>nul
if errorlevel 1 (
  echo [ERRO] Git não encontrado. Instale o Git for Windows e tente novamente.
  pause
  exit /b 1
)

echo [1/10] Copiando arquivos v19 para a pasta do projeto...
robocopy "%SRC%" "%PROJETO%" /E /XD ".git" "node_modules" ".netlify" /XF "PUBLICAR_V19_CORRIGIDO.cmd" "*.env" ".env" ".env.*" >nul
if errorlevel 8 (
  echo [ERRO] Falha ao copiar arquivos.
  pause
  exit /b 1
)

cd /d "%PROJETO%"

echo [2/10] Protegendo segredos no .gitignore...
(
 echo .env
 echo .env.*
 echo node_modules/
 echo .netlify/
 echo *.cmd
 echo *.bat
 echo *.exe
 echo *.ps1
 echo *.key
 echo *.pem
 echo service_role*
 echo *SERVICE_ROLE*
 echo *SECRET_KEY*
 echo *SUPABASE_SERVICE*
) > .gitignore

echo [3/10] Inicializando Git se necessário...
if not exist ".git" git init

echo [4/10] Configurando branch...
git branch -M %BRANCH%

echo [5/10] Configurando remote...
git remote remove origin >nul 2>nul
git remote add origin %REPO%

echo [6/10] Sincronizando com GitHub...
git pull origin %BRANCH% --rebase --autostash
if errorlevel 1 (
  echo [AVISO] Não foi possível sincronizar automaticamente. Continuando com push forçado seguro da branch local.
)

echo [7/10] Adicionando arquivos...
git add .

echo [8/10] Removendo arquivos sensíveis do commit...
git rm --cached -r .env .env.* node_modules .netlify 2>nul

echo.
echo Arquivos preparados para commit:
git status --short

echo.
echo [9/10] Criando commit...
git commit -m "Atualizacao v19 custos completos painel obras STEP"
if errorlevel 1 (
  echo [INFO] Nenhuma alteração nova para commitar, ou commit já existente.
)

echo [10/10] Enviando para o GitHub...
git push -u origin %BRANCH%
if errorlevel 1 (
  echo.
  echo [ERRO] Falha ao enviar para o GitHub.
  echo Verifique se fez login com uma conta que tem permissão no repositório:
  echo %REPO%
  pause
  exit /b 1
)

echo.
echo ======================================================
echo   SUCESSO: v19 enviada para o GitHub.
echo ======================================================
echo.
echo Próximo passo:
echo 1. No Netlify, faça: Deploys - Trigger deploy - Clear cache and deploy site
echo 2. No Supabase, rode: supabase\RODAR_ESTE_SQL_V19_CUSTOS_COMPLETOS.sql
echo 3. No painel, clique em Recarregar banco.
echo.
pause
