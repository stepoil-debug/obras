@echo off
chcp 65001 >nul
setlocal EnableExtensions EnableDelayedExpansion

echo ======================================================
echo   STEP OBRAS - PUBLICAR V22 MAPA RESPONSIVO
echo ======================================================

set "SRC=%~dp0"
set "DST=C:\Users\douglas.tabella\Downloads\Obras Base Step\step_painel_obras_netlify_v5"
set "REPO=https://github.com/stepsolutions-obras/stepsolutions-obrasbase.git"
set "BRANCH=main"

if not exist "%DST%" (
  echo Pasta destino nao encontrada:
  echo %DST%
  pause
  exit /b 1
)

echo [1/8] Copiando arquivos v22 para a pasta do projeto...
robocopy "%SRC%" "%DST%" /E /XD .git node_modules .netlify /XF *.cmd *.bat *.exe .env .env.* >nul
if errorlevel 8 (
  echo Erro ao copiar arquivos.
  pause
  exit /b 1
)

cd /d "%DST%"

echo [2/8] Garantindo .gitignore de seguranca...
(
 echo .env
 echo .env.*
 echo node_modules/
 echo .netlify/
 echo *.cmd
 echo *.bat
 echo *.exe
 echo SUPABASE_SERVICE_ROLE_KEY
 echo SUPABASE_SECRET_KEY
) > .gitignore

echo [3/8] Inicializando Git se necessario...
if not exist .git git init

echo [4/8] Configurando branch e remote...
git branch -M %BRANCH%
git remote remove origin >nul 2>&1
git remote add origin %REPO%

echo [5/8] Sincronizando com GitHub...
git pull origin %BRANCH% --allow-unrelated-histories --no-edit

echo [6/8] Preparando commit...
git add .
git rm --cached -r .env .env.* node_modules .netlify 2>nul

echo Arquivos preparados:
git status --short

echo [7/8] Commit...
git commit -m "V22 corrige exibicao do mapa no celular" || echo Nada novo para commitar.

echo [8/8] Push para GitHub...
git push -u origin %BRANCH%

echo ======================================================
echo   PUBLICACAO V22 ENVIADA PARA O GITHUB.
echo ======================================================
echo Depois no Netlify: Deploys ^> Trigger deploy ^> Clear cache and deploy site.
echo No painel: Mapa da Planta ^> Ajustar tela, caso o navegador mantenha cache de zoom antigo.
pause
