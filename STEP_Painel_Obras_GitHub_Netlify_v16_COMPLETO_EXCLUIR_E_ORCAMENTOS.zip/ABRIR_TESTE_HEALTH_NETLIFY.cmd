@echo off
start "" "https://stepsolution-obras.netlify.app/.netlify/functions/obras?health=1"
