@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul

echo ======================================================
echo   STEP OBRAS BASE - PUBLICAR V18
echo   Corrige custos + botão Tabela de custo no mapa
echo ======================================================
echo.

set "TARGET=C:\Users\douglas.tabella\Downloads\Obras Base Step\step_painel_obras_netlify_v5"
set "REPO=https://github.com/stepsolutions-obras/stepsolutions-obrasbase.git"
set "BRANCH=main"
set "SOURCE=%~dp0site"

echo Pasta destino: "%TARGET%"
echo Repositorio: %REPO%
echo.

where git >nul 2>nul
if errorlevel 1 (
  echo ERRO: Git nao encontrado. Instale o Git para Windows.
  pause
  exit /b 1
)

if not exist "%SOURCE%\index.html" (
  echo ERRO: Nao encontrei a pasta site ao lado deste CMD.
  pause
  exit /b 1
)

if not exist "%TARGET%" mkdir "%TARGET%"

echo [1/8] Copiando arquivos v18 para a pasta do projeto...
robocopy "%SOURCE%" "%TARGET%" /E /NFL /NDL /NJH /NJS /NC /NS /XD .git node_modules .netlify /XF .env *.cmd *.bat *.exe >nul
if errorlevel 8 (
  echo ERRO ao copiar arquivos.
  pause
  exit /b 1
)

cd /d "%TARGET%"

echo [2/8] Protegendo arquivos sensiveis no .gitignore...
(
  echo .env
  echo .env.*
  echo !.env.example
  echo node_modules/
  echo .netlify/
  echo *.cmd
  echo *.bat
  echo *.exe
  echo *service_role*
  echo *SERVICE_ROLE*
  echo *SECRET_KEY*
) > .gitignore

echo [3/8] Inicializando Git se necessario...
if not exist ".git" git init

echo [4/8] Configurando branch e remote...
git checkout -B %BRANCH%
git remote remove origin >nul 2>nul
git remote add origin %REPO%

echo [5/8] Sincronizando com GitHub...
git pull origin %BRANCH% --allow-unrelated-histories --no-edit

echo [6/8] Adicionando arquivos...
git add -A
git reset -- .env .env.* *.cmd *.bat *.exe >nul 2>nul

echo Arquivos preparados:
git status --short

echo [7/8] Commit...
git commit -m "Atualizacao painel obras STEP v18 custos mapa" || echo Nenhuma alteracao nova para commit.

echo [8/8] Push...
git push -u origin %BRANCH%

echo.
echo ======================================================
echo   FINALIZADO: V18 enviada para o GitHub.
echo ======================================================
echo Agora no Netlify: Deploys ^> Trigger deploy ^> Clear cache and deploy site.
echo.
pause
