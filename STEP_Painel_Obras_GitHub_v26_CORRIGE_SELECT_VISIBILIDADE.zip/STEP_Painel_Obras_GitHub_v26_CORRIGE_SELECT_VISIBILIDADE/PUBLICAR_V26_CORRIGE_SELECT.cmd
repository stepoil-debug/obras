@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

set "SRC=%~dp0"
set "DST=C:\Users\douglas.tabella\Downloads\Obras Base Step\step_painel_obras_netlify_v5"
set "REPO=https://github.com/stepsolutions-obras/stepsolutions-obrasbase.git"
set "BRANCH=main"

echo ======================================================
echo   STEP OBRAS - PUBLICAR V26 CORRIGE SELECT/FILTROS
echo ======================================================
echo.
echo Origem: "%SRC%"
echo Destino: "%DST%"
echo Repositorio: %REPO%
echo.

if not exist "%DST%" (
  echo ERRO: Pasta destino nao encontrada.
  pause
  exit /b 1
)

where git >nul 2>nul
if errorlevel 1 (
  echo ERRO: Git nao encontrado. Instale o Git for Windows.
  pause
  exit /b 1
)

echo [1/6] Copiando arquivos v26 para a pasta do projeto...
robocopy "%SRC%" "%DST%" /E /XD .git node_modules .netlify /XF .env *.cmd *.bat *.exe >nul
if errorlevel 8 (
  echo ERRO ao copiar arquivos.
  pause
  exit /b 1
)

echo [2/6] Entrando na pasta do projeto...
cd /d "%DST%"

echo [3/6] Protegendo arquivos locais/sensiveis...
(
 echo .env
 echo .env.*
 echo node_modules/
 echo .netlify/
 echo *.cmd
 echo *.bat
 echo *.exe
 echo *.log
) > .gitignore

echo [4/6] Configurando Git...
if not exist ".git" git init
git branch -M %BRANCH%
git remote remove origin >nul 2>nul
git remote add origin %REPO%

echo [5/6] Preparando commit...
git add .
git reset -- .env .env.* *.cmd *.bat *.exe >nul 2>nul
git status --short

echo [6/6] Enviando para GitHub...
git commit -m "Atualizacao v26 corrige visibilidade filtros" || echo Nada novo para commitar.
git push -u origin %BRANCH%

echo.
echo ======================================================
echo   CONCLUIDO: v26 enviada para o GitHub.
echo ======================================================
echo Depois, no Netlify, use Clear cache and deploy site se precisar.
echo.
pause
