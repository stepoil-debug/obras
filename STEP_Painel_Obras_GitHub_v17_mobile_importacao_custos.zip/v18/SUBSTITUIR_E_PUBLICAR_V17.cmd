@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul

title STEP OBRAS - PUBLICAR V17

echo ======================================================
echo   STEP OBRAS BASE - PUBLICADOR V17
echo ======================================================
echo.

set "SOURCE=%~dp0site"
set "PROJECT=C:\Users\douglas.tabella\Downloads\Obras Base Step\step_painel_obras_netlify_v5"
set "REPO=https://github.com/stepsolutions-obras/stepsolutions-obrasbase.git"
set "BRANCH=main"

echo Fonte v17: "%SOURCE%"
echo Pasta destino: "%PROJECT%"
echo Repositorio: %REPO%
echo.

if not exist "%SOURCE%\index.html" (
  echo ERRO: Nao encontrei "%SOURCE%\index.html".
  echo Extraia o ZIP completo antes de executar este CMD.
  pause
  exit /b 1
)

where git >nul 2>nul
if errorlevel 1 (
  echo ERRO: Git nao encontrado. Instale o Git for Windows.
  pause
  exit /b 1
)

if not exist "%PROJECT%" mkdir "%PROJECT%"

echo [1/9] Copiando arquivos v17 para a pasta oficial...
robocopy "%SOURCE%" "%PROJECT%" /E /XD ".git" "node_modules" ".netlify" /XF ".env" ".env.*" "*.cmd" "*.bat" "*.exe" >nul
set "RC=%ERRORLEVEL%"
if %RC% GEQ 8 (
  echo ERRO: Falha no robocopy. Codigo %RC%.
  pause
  exit /b 1
)

cd /d "%PROJECT%" || (
  echo ERRO: Nao consegui acessar a pasta do projeto.
  pause
  exit /b 1
)

echo [2/9] Confirmando versao no index.html...
findstr /C:"Versão v17" index.html >nul
if errorlevel 1 (
  echo ERRO: O index.html copiado nao parece ser v17.
  echo Abra o arquivo e confirme se o ZIP foi extraido corretamente.
  pause
  exit /b 1
)
echo OK: index.html v17 confirmado.

echo [3/9] Protegendo arquivos sensiveis no .gitignore...
(
  echo.
  echo # Protecoes locais STEP Obras
  echo .env
  echo .env.*
  echo node_modules/
  echo .netlify/
  echo *.cmd
  echo *.bat
  echo *.exe
  echo service-role*.txt
  echo *service_role*
  echo *secret_key*
) >> .gitignore

echo [4/9] Inicializando Git se necessario...
if not exist ".git" git init

echo [5/9] Configurando branch e remote...
git branch -M %BRANCH%
git remote remove origin >nul 2>nul
git remote add origin %REPO%

echo [6/9] Sincronizando com GitHub...
git pull origin %BRANCH% --rebase --autostash
if errorlevel 1 (
  echo AVISO: pull com rebase falhou. Tentando pull com allow-unrelated-histories...
  git pull origin %BRANCH% --allow-unrelated-histories --autostash
)

echo [7/9] Preparando arquivos para commit...
git add -A
git reset -- .env .env.* >nul 2>nul
git reset -- *.cmd *.bat *.exe >nul 2>nul

echo.
echo Arquivos alterados/preparados:
git status --short

echo.
echo [8/9] Criando commit...
git diff --cached --quiet
if not errorlevel 1 (
  echo Nao ha alteracoes para commit. Confira se o site ja esta em v17 no GitHub.
) else (
  git commit -m "Publica painel STEP Obras v17 mobile importacao custos"
  if errorlevel 1 (
    echo ERRO: falha ao criar commit.
    pause
    exit /b 1
  )
)

echo [9/9] Enviando para GitHub...
echo Se abrir login, use a conta com permissao no repositorio.
git push -u origin %BRANCH%
if errorlevel 1 (
  echo.
  echo ERRO: falha no push. Verifique login/permissao no GitHub.
  pause
  exit /b 1
)

echo.
echo ======================================================
echo   SUCESSO: v17 enviada para o GitHub.
echo ======================================================
echo.
echo Agora faca nova publicacao com limpeza de cache no painel de deploy.
echo.
echo Teste apos publicar:
echo https://stepsolution-obras.netlify.app/api/obras?health=1
echo.
pause
